import React, { createContext, useContext, useState, useCallback } from "react";
import { User, UserRole } from "@/types/expense";
import { USERS } from "@/data/store";

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => { success: boolean; error?: string };
  logout: () => void;
  switchRole: (role: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback(
    (email: string, _password: string): { success: boolean; error?: string } => {
      const found = USERS.find(
        (u) => u.email.toLowerCase() === email.toLowerCase()
      );
      if (!found) {
        return { success: false, error: "Invalid email or password" };
      }
      // In a real app, validate password / JWT here
      setUser(found);
      return { success: true };
    },
    []
  );

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const switchRole = useCallback((role: UserRole) => {
    const found = USERS.find((u) => u.role === role);
    if (found) setUser(found);
  }, []);

  return (
    <AuthContext.Provider
      value={{ user, isAuthenticated: !!user, login, logout, switchRole }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
